#include "Circle.h"

Circle::Circle(Point x,  double r): Figure(1), m_radius(r){
    m_points[0] = &x;
}

Circle::~Circle(){

}

double Circle::area() const{

    return 0;
}
