#include "Figure.h"

Figure::Figure(int numOfPoints): m_numOfPoints(numOfPoints){
    m_points = new Point * [numOfPoints];
    for(int i = 0; i < m_numOfPoints; i ++)
        m_points[i] = new Point(0.0, 0.0); 
}

Figure::~Figure(){
    for(int i = 0; i < m_numOfPoints; i++)
        delete m_points[i];
    delete [] m_points;
}

void Figure::print() const{
    std::cout << "Figure : [";
    for (int i = 0; i < m_numOfPoints; i ++)
        std::cout << *m_points[i] << " ";
    std::cout << "]" << std::endl; 
}

double Figure::length() const{
    double len;
    len = m_points[1]->distance((*m_points)[2]);
    return len;
}

void Figure::setPoint(int pos, double x, double y){
    m_points[pos]->setCoordinates(x,y);
        
}

void Figure::move(const double x, const double y){
    for(int i = 0 ; i < m_numOfPoints; i++)
        m_points[i]->move(x,y);
}

void Figure::scale(const Point & p, const double scale){

}
    
void Figure::rotate(const Point & p, const double angle){

}