#include "Transformable.h"

const double Transformable::PI = 3.141592653589793238463;
