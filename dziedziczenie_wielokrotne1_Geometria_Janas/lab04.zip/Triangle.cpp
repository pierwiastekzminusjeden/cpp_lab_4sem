#include "Triangle.h"


Triangle::Triangle(Point x, Point y, Point z): Figure(3){
   m_points[0] = &x;
   m_points[1] = &y;
   m_points[2] = &z;
}

Triangle::Triangle(const Triangle & toCopy): Figure(3){
    m_points[0] = toCopy.m_points[0];
    m_points[1] = toCopy.m_points[1];
    m_points[2] = toCopy.m_points[2];
}

Triangle::~Triangle(){
}

double Triangle::area() const{

    return 0;
}